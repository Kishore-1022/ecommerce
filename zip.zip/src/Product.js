
export const products=[
        { 
            id:1,
            name:'APPLE iPhone 15Pro',
            price:79900,
            quantity:1,
            rating:4.6,
            img1:'https://m.media-amazon.com/images/I/81dT7CUY6GL._SX679_.jpg',
            img2:'https://m.media-amazon.com/images/I/71TSx9D2BVL._SX679_.jpg',
            img3:'https://m.media-amazon.com/images/I/61Jrsu9d3-L._SX679_.jpg',
        },
        {
            id:2,
            name:'APPLE Watch Ultra 2',
            price:89900,
            quantity:1,
            rating:4.3,
            img1:'https://ecsmedia.pl/c/apple-watch-series-3-38-mm-bialy-b-iext53602858.jpg',
            img2:'https://icenter.ua/image/cache/catalog/image/cache/catalog/1973/1973_5-700x700.webp',
            img3:'https://i5.walmartimages.com/seo/Apple-Watch-Series-2-38mm-Aluminum-Case-with-Band_745de384-872f-4fcc-b34f-9bc8a1b750cb.8278726a91a5e4e580f0ba35806c9a34.jpeg',
        },
        {
            id:3,
            name:'APPLE iPad Air',
            price:50900,
            quantity:1,
            rating:4.7,
            img1:'https://wibi.com.kw/cdn/shop/products/buy-apple-ipad-air-5th-gen-m1-chip-64gb-109-liquid-retina-wi-fi-1yw-space-grey-tablet-wibi-want-it-buy-it-kuwait-282158.jpg?v=1661351378',
            img2:'https://www.apple.com/newsroom/images/product/ipad/standard/apple_new-ipad-air_new-design_09152020.jpg.landing-big_2x.jpg',
            img3:'https://res.cloudinary.com/grover/image/upload/e_trim/b_white,c_pad,dpr_2.0,h_500,w_520/f_auto,q_auto/v1649406991/zwjkahf704vdzmals7e9.png',
        },
        {
            id:4,
            name:'APPLE MacBook AIR',
            price:109000,
            quantity:1,
            rating:4.7,
            img1:'https://www.technoworld.com/media/catalog/product/cache/941012141e93b216d64d157444571b98/m/n/mnej3b-a.jpg',
            img2:'https://i0.wp.com/price.zoombangla.com/wp-content/uploads/2022/09/apple-macbook-pro-late-2020-apple-m1-chip-133-11627648263-600x600.webp',
            img3:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQe0rBuzJz-UlSB0At4KBZLQkSujV2gz1j9Jd2lMXdO16wzZCJoIbkpcnqZMEU_bdhat3s&usqp=CAU',
        },
        {
            id:5,
            name:'APPLE AirPods Pro',
            price:24400,
            rating:4.1,
            quantity:1,
            img1:'https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/MME73?wid=445&hei=445&fmt=jpeg&qlt=95&.v=1632861342000',
            img2:'https://tienda.bananacomputer.com/cms/uploads/webp/812F91CA-C545-4ECA-BE5E-A9A4A25E1FB3-750-rhuwvr.webp',
            img3:'https://media.studio7thailand.com/76563/Apple-Acc-AirPods-Pro-(2nd-generation)-1-square_medium.jpg',
        },
        {
            id:6,
            name:'APPLE MagSafe Battery Pack',
            price:4999,
            rating:4.6,
            quantity:1,
            img1:'https://unione.co.in/cdn/shop/products/9494.jpg?v=1662119250&width=1471.656&height=1471.656',
            img2:'https://dimensiva.com/wp-content/uploads/edd/2021/07/magsafe-battery-pack-by-apple.jpg',
            img3:'https://www.aptronixindia.com/media/catalog/product/cache/31f0162e6f7d821d2237f39577122a8a/m/j/mjwy3-2-removebg-preview.png',
        },
        {
            id:7,
            name:'APPLE TV 4K',
            price:497599,
            rating:4.8,
            quantity:1,
            img1:'https://m.media-amazon.com/images/I/816DD5Kg7mL._SL1500_.jpg',
            img2:'https://m.media-amazon.com/images/I/81oEIytsw8L._SL1500_.jpg',
            img3:'https://m.media-amazon.com/images/I/41LpF5n38kL._SL1024_.jpg',
        },
        {
            id:8,
            name:'APPLE HomePod',
            price:32900,
            rating:4.3,
            quantity:1,
            img1:'https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/homepod-select-midnight-202210?wid=470&hei=556&fmt=png-alpha&.v=1670557210097',
            img2:'https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/homepod-select-white-202210?wid=470&hei=556&fmt=png-alpha&.v=1670557209531',
            img3:'https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/homepod-mini-select-spacegray-202110_FV1?wid=934&hei=440&fmt=jpeg&qlt=95&.v=1633086020000',
        }


        
    ]
  



